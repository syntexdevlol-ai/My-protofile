# Example Project
This is a sample project to demonstrate the viewer.
It has multiple lines of text to test the truncation feature.
You can add more folders like this one to the 'projects' directory.
